<?php
session_start();
if (!isset($_SESSION['id_utente'])) {
    header('Location: login.php');
    exit();
}

// Connessione al database
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$messaggio = "";

// Preleva liste per i dropdown
$campi = $conn->query("SELECT id_campo, indirizzo FROM campi");
$calcetti = $conn->query("
    SELECT c.id_calcetto,
           CONCAT(DATE_FORMAT(c.data_ora,'%d/%m/%Y %H:%i'),' @ ',ca.indirizzo) AS descrizione
    FROM calcetti c
    JOIN campi ca ON c.id_campo = ca.id_campo
    ORDER BY c.data_ora ASC
");

// Gestione inserimento commento
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type'], $_POST['commento'])) {
    $type      = $_POST['type'];               // "campo" o "calcetto"
    $testo     = trim($_POST['commento']);
    $id_utente = (int)$_SESSION['id_utente'];
    $data_comm = date('Y-m-d H:i:s');

    if ($testo === "") {
        $messaggio = "❌ Il commento non può essere vuoto.";
    } else {
        if ($type === 'campo' && isset($_POST['id_campo'])) {
            $id_campo = (int)$_POST['id_campo'];
            $stmt = $conn->prepare("
                INSERT INTO commenti (testo, data_commento, id_utente, id_campo)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param("sssi", $testo, $data_comm, $id_utente, $id_campo);
        } elseif ($type === 'calcetto' && isset($_POST['id_calcetto'])) {
            $id_calcetto = (int)$_POST['id_calcetto'];
            $stmt = $conn->prepare("
                INSERT INTO commenti (testo, data_commento, id_utente, id_calcetto)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param("sssi", $testo, $data_comm, $id_utente, $id_calcetto);
        } else {
            $stmt = null;
            $messaggio = "❌ Tipo o ID non valido.";
        }

        if ($stmt) {
            if ($stmt->execute()) {
                $messaggio = "✅ Commento salvato con successo.";
            } else {
                $messaggio = "❌ Errore: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// Preleva tutte le recensioni (commenti)
$recRes = $conn->query("
    SELECT cm.testo, cm.data_commento, u.nome, u.cognome,
           c.indirizzo AS campo_indirizzo,
           CONCAT(ca.indirizzo,' — ',DATE_FORMAT(cal.data_ora,'%d/%m/%Y %H:%i')) AS calcetto_descr
    FROM commenti cm
    JOIN utenti u ON cm.id_utente = u.id_utente
    LEFT JOIN campi c    ON cm.id_campo    = c.id_campo
    LEFT JOIN calcetti cal ON cm.id_calcetto = cal.id_calcetto
    LEFT JOIN campi ca   ON cal.id_campo    = ca.id_campo
    ORDER BY cm.data_commento DESC
");

$conn->close();
?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <title>Commenti - Sportify</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { font-family: Arial, sans-serif; background:#f4f4f4; margin:0; padding:20px; }
    .container {
      max-width:800px; margin:auto; background:white;
      padding:20px; border-radius:8px;
      box-shadow:0 0 10px rgba(0,0,0,0.1);
    }
    h1, h2 { text-align:center; color:#1976D2; }
    .message { text-align:center; color:green; margin-bottom:15px; }
    form { margin-bottom:30px; }
    .form-group { margin-bottom:15px; }
    label { display:block; font-weight:bold; margin-bottom:5px; }
    select, textarea {
      width:100%; padding:8px; border:1px solid #ccc;
      border-radius:4px; box-sizing:border-box;
      font-size:1rem;
    }
    textarea { height:80px; resize:vertical; }
    input[type="submit"], .btn-home, .btn-logout {
      padding:8px 12px; background:#4CAF50; color:white;
      border:none; border-radius:4px; cursor:pointer;
      text-decoration:none; display:inline-block; margin-top:10px;
    }
    input[type="submit"]:hover, .btn-home:hover, .btn-logout:hover {
      background:#45a049;
    }
    table { width:100%; border-collapse:collapse; margin-top:20px; }
    th, td { padding:8px; border:1px solid #ddd; text-align:left; }
    th { background:#e3f2fd; }
    .tipo { font-style:italic; color:#555; }
  </style>
</head>
<body>
  <div class="container">
    <a href="index.php" class="btn-home">🏠 Home</a>
    <a href="logout.php" class="btn-logout">🚪 Logout</a>

    <h1>Commenti</h1>
    <?php if ($messaggio): ?>
      <p class="message"><?= htmlspecialchars($messaggio) ?></p>
    <?php endif; ?>

    <!-- Commenta un Campo -->
    <h2>Commenta un Campo</h2>
    <form method="POST">
      <input type="hidden" name="type" value="campo">
      <div class="form-group">
        <label for="id_campo">Seleziona Campo:</label>
        <select id="id_campo" name="id_campo" required>
          <option value="">-- Scegli --</option>
          <?php while ($r = $campi->fetch_assoc()): ?>
            <option value="<?= $r['id_campo'] ?>">
              <?= htmlspecialchars($r['indirizzo']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="form-group">
        <label for="commento">Commento:</label>
        <textarea id="commento" name="commento" required></textarea>
      </div>
      <input type="submit" value="Invia Commento">
    </form>

    <!-- Commenta un Calcetto -->
    <h2>Commenta un Calcetto</h2>
    <form method="POST">
      <input type="hidden" name="type" value="calcetto">
      <div class="form-group">
        <label for="id_calcetto">Seleziona Calcetto:</label>
        <select id="id_calcetto" name="id_calcetto" required>
          <option value="">-- Scegli --</option>
          <?php while ($r = $calcetti->fetch_assoc()): ?>
            <option value="<?= $r['id_calcetto'] ?>">
              <?= htmlspecialchars($r['descrizione']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="form-group">
        <label for="commento2">Commento:</label>
        <textarea id="commento2" name="commento" required></textarea>
      </div>
      <input type="submit" value="Invia Commento">
    </form>

    <!-- Tutti i Commenti -->
    <h2>Tutti i Commenti</h2>
    <?php if ($recRes->num_rows): ?>
      <table>
        <tr>
          <th>Tipo</th>
          <th>Target</th>
          <th>Utente</th>
          <th>Commento</th>
          <th>Data</th>
        </tr>
        <?php while ($r = $recRes->fetch_assoc()): ?>
          <tr>
            <td class="tipo">
              <?= $r['campo_indirizzo'] ? 'Campo' : 'Calcetto' ?>
            </td>
            <td>
              <?= $r['campo_indirizzo']
                   ? htmlspecialchars($r['campo_indirizzo'])
                   : htmlspecialchars($r['calcetto_descr']); ?>
            </td>
            <td><?= htmlspecialchars($r['nome'].' '.$r['cognome']) ?></td>
            <td><?= nl2br(htmlspecialchars($r['testo'])) ?></td>
            <td><?= $r['data_commento'] ?></td>
          </tr>
        <?php endwhile; ?>
      </table>
    <?php else: ?>
      <p>Nessun commento disponibile.</p>
    <?php endif; ?>
  </div>
</body>
</html>
