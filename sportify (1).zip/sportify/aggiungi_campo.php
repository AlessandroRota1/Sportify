<?php
session_start();

// Connessione al database
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$messaggio = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // 1) Indirizzo "pulito" per il DB
    $indirizzo_raw = mysqli_real_escape_string($conn, $_POST['posizione']);

    // 2) Altri campi
    $terreno     = mysqli_real_escape_string($conn, $_POST['terreno']);
    $spogliatoi  = (int) $_POST['spogliatoi'];
    $n_giocatori = (int) $_POST['n_giocatori'];
    $docce       = (int) $_POST['docce'];
    $costo       = (float) $_POST['costo'];
    $id_utente   = (int) $_SESSION['id_utente'];

    // 3) URL‑encode solo per geocoding
    $indirizzo_encoded = urlencode($indirizzo_raw);
    $geocodeUrl = "https://nominatim.openstreetmap.org/search?format=json&q={$indirizzo_encoded}";

    // Intestazione richiesta a Nominatim
    $options = [
        "http" => [
            "header" => "User-Agent: SportifyApp/1.0 (contatto@tuodominio.com)"
        ]
    ];
    $context         = stream_context_create($options);
    $geocodeResponse = @file_get_contents($geocodeUrl, false, $context);
    $geocodeData     = $geocodeResponse ? json_decode($geocodeResponse) : null;

    if ($geocodeData && isset($geocodeData[0])) {
        $lat = $geocodeData[0]->lat;
        $lng = $geocodeData[0]->lon;

        // 4) Inserimento nel DB con l'indirizzo "pulito"
        $sql = "INSERT INTO campi
                (indirizzo, terreno, spogliatoi, n_giocatori, docce, costo, id_utente, latitudine, longitudine)
                VALUES
                ('$indirizzo_raw', '$terreno', $spogliatoi, $n_giocatori, $docce, $costo, $id_utente, '$lat', '$lng')";

        if ($conn->query($sql) === TRUE) {
            $messaggio = "Campo aggiunto con successo!";
        } else {
            $messaggio = "Errore durante l'aggiunta del campo: " . $conn->error;
        }
    } else {
        $messaggio = "Indirizzo non valido o non geocodificabile.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aggiungi Campo - Sportify</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin:0; padding:0; }
        .container { width:50%; margin:30px auto; background:#fff; padding:20px;
                     box-shadow:0 0 10px rgba(0,0,0,0.1); border-radius:8px; }
        h1 { text-align:center; margin-bottom:20px; }
        .form-group { margin-bottom:15px; }
        label { display:block; font-weight:bold; margin-bottom:5px; }
        input, select { width:100%; padding:10px; border:1px solid #ccc; border-radius:5px; }
        input[type="submit"], .btn-home {
            width:100%; padding:10px; margin-top:10px; background:#4CAF50;
            color:#fff; border:none; border-radius:5px; cursor:pointer; text-align:center;
        }
        input[type="submit"]:hover, .btn-home:hover { background:#45a049; }
        .message { text-align:center; color:green; margin-bottom:15px; }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="btn-home">🏠 Torna alla Home</a>
        <h1>Aggiungi Campo da Calcio</h1>
        <?php if ($messaggio): ?>
            <p class="message"><?= htmlspecialchars($messaggio) ?></p>
        <?php endif; ?>

        <form action="aggiungi_campo.php" method="POST">
            <div class="form-group">
                <label for="posizione">Posizione (Indirizzo):</label>
                <input type="text" id="posizione" name="posizione" required>
            </div>
            <div class="form-group">
                <label for="terreno">Tipo di terreno:</label>
                <select id="terreno" name="terreno" required>
                    <option value="Erba">Erba</option>
                    <option value="Sintetico">Sintetico</option>
                    <option value="Palestra">Palestra</option>
                    <option value="Ghiaia">Ghiaia</option>
                </select>
            </div>
            <div class="form-group">
                <label for="spogliatoi">Spogliatoi disponibili:</label>
                <select id="spogliatoi" name="spogliatoi" required>
                    <option value="1">Sì</option>
                    <option value="0">No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="n_giocatori">Numero giocatori per squadra:</label>
                <select id="n_giocatori" name="n_giocatori" required>
                    <option value="5">5</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="11">11</option>
                </select>
            </div>
            <div class="form-group">
                <label for="docce">Docce disponibili:</label>
                <select id="docce" name="docce" required>
                    <option value="1">Sì</option>
                    <option value="0">No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="costo">Inserisci costo orario (€):</label>
                <input type="number" step="0.01" id="costo" name="costo" required>
            </div>
            <input type="submit" value="Aggiungi Campo">
        </form>
    </div>
</body>
</html>
