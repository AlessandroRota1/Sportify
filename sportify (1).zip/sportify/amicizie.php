<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connessione fallita: " . $conn->connect_error);

$id_utente = $_SESSION['id_utente'] ?? 0;
$messaggio = "";

// INVIO richiesta amicizia
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nickname'])) {
    $nickname = $conn->real_escape_string($_POST['nickname']);

    $res = $conn->query("SELECT id_utente FROM utenti WHERE nickname = '$nickname'");
    if ($res->num_rows) {
        $row = $res->fetch_assoc();
        $destinatario = $row['id_utente'];

        if ($destinatario == $id_utente) {
            $messaggio = "Non puoi inviare una richiesta a te stesso.";
        } else {
            $esiste = $conn->query("
                SELECT 1 FROM amicizie
                WHERE 
                    (id_mittente = $id_utente AND id_destinatario = $destinatario)
                    OR
                    (id_mittente = $destinatario AND id_destinatario = $id_utente)
            ");
            if ($esiste->num_rows) {
                $messaggio = "Richiesta già esistente o utente già amico.";
            } else {
                $data = date('Y-m-d');
                $conn->query("INSERT INTO amicizie (id_mittente, id_destinatario, stato, data_richiesta)
                              VALUES ($id_utente, $destinatario, 'in_attesa', '$data')");
                $messaggio = "Richiesta inviata!";
            }
        }
    } else {
        $messaggio = "Utente non trovato.";
    }
}

// ACCETTA o RIFIUTA richiesta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['azione'], $_POST['richiesta_id'])) {
    $azione = $_POST['azione'];
    $idRichiesta = (int)$_POST['richiesta_id'];
    $nuovoStato = ($azione === 'accetta') ? 'accettata' : 'rifiutata';

    $conn->query("UPDATE amicizie SET stato = '$nuovoStato' WHERE id = $idRichiesta AND id_destinatario = $id_utente");
}

// Elenco richieste ricevute
$richieste = $conn->query("
    SELECT a.id, u.nickname, u.nome, u.cognome
    FROM amicizie a
    JOIN utenti u ON u.id_utente = a.id_mittente
    WHERE a.id_destinatario = $id_utente AND a.stato = 'in_attesa'
");

// Elenco amici
$amici = $conn->query("
    SELECT u.id_utente, u.nickname, u.nome, u.cognome
    FROM amicizie a
    JOIN utenti u ON 
        (u.id_utente = a.id_mittente AND a.id_destinatario = $id_utente)
        OR (u.id_utente = a.id_destinatario AND a.id_mittente = $id_utente)
    WHERE a.stato = 'accettata' AND u.id_utente != $id_utente
");

// Recupero calcetti creati dall'utente
$calcetti = $conn->query("
    SELECT id_calcetto, data_ora 
    FROM calcetti 
    WHERE id_utente = $id_utente
");

$lista_calcetti = [];
while ($c = $calcetti->fetch_assoc()) {
    $lista_calcetti[] = $c;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Gestione Amicizie</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f4f4;
            padding: 30px;
        }

        .container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            color: #1976D2;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        input[type=text], select {
            width: 100%;
            padding: 8px;
            margin: 5px 0 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type=submit], .btn-small {
            padding: 10px 15px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type=submit]:hover, .btn-small:hover {
            background: #45a049;
        }

        .message {
            color: green;
            margin-bottom: 15px;
            text-align: center;
        }

        .section {
            margin-top: 30px;
        }

        .card {
            background: #f0f0f0;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }

        .accept {
            background: #4CAF50;
            color: white;
        }

        .reject {
            background: #f44336;
            color: white;
        }

        .top-links {
            text-align: right;
            margin-bottom: 20px;
        }

        .top-links a {
            padding: 8px 14px;
            background-color: #1976D2;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }

        .top-links a:hover {
            background-color: #0D47A1;
        }

        .inline-form {
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="top-links">
        <a href="index.php">🏠 Torna alla Home</a>
    </div>

    <h1>🤝 Gestione Amicizie</h1>
    <?php if ($messaggio): ?><p class="message"><?= $messaggio ?></p><?php endif; ?>

    <form method="POST">
        <label for="nickname">Invia richiesta amicizia per nickname:</label>
        <input type="text" name="nickname" id="nickname" required>
        <input type="submit" value="Invia Richiesta">
    </form>

    <div class="section">
        <h2>📨 Richieste ricevute</h2>
        <?php if ($richieste->num_rows): ?>
            <?php while ($r = $richieste->fetch_assoc()): ?>
                <div class="card">
                    <strong><?= htmlspecialchars($r['nickname']) ?></strong> (<?= $r['nome'] ?> <?= $r['cognome'] ?>)
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="richiesta_id" value="<?= $r['id'] ?>">
                        <button type="submit" name="azione" value="accetta" class="btn-small accept">Accetta</button>
                        <button type="submit" name="azione" value="rifiuta" class="btn-small reject">Rifiuta</button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Nessuna richiesta in attesa.</p>
        <?php endif; ?>
    </div>

    <div class="section">
        <h2>👥 I tuoi amici</h2>
        <?php if ($amici->num_rows): ?>
            <?php while ($a = $amici->fetch_assoc()): ?>
                <div class="card">
                    <?= htmlspecialchars($a['nome'] . ' ' . $a['cognome']) ?> (<?= htmlspecialchars($a['nickname']) ?>)

                    <?php if (count($lista_calcetti)): ?>
                        <form action="invia_invito.php" method="POST" class="inline-form">
                            <input type="hidden" name="id_destinatario" value="<?= $a['id_utente'] ?>">
                            <label for="id_calcetto">Invita a un tuo calcetto:</label>
                            <select name="id_calcetto" required>
                                <option value="">-- Seleziona --</option>
                                <?php foreach ($lista_calcetti as $c): ?>
                                    <option value="<?= $c['id_calcetto'] ?>"><?= $c['data_ora'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn-small">Invia Invito</button>
                        </form>
                    <?php else: ?>
                        <p><em>Non hai creato nessun calcetto da invitare.</em></p>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Non hai ancora amici.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
