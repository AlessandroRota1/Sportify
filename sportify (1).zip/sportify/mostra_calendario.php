<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connessione fallita: " . $conn->connect_error);

if (!isset($_GET['id_torneo'])) {
    die("Torneo non specificato.");
}

$id_torneo = (int)$_GET['id_torneo'];
$id_utente = $_SESSION['id_utente'] ?? 0;

// Gestione inserimento risultato
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['salva_risultato'])) {
    $id_partita = (int)$_POST['id_partita'];
    $gol_1 = (int)$_POST['gol_1'];
    $gol_2 = (int)$_POST['gol_2'];

    $update = $conn->prepare("UPDATE partite SET gol_1 = ?, gol_2 = ? WHERE id_partita = ?");
    $update->bind_param("iii", $gol_1, $gol_2, $id_partita);
    $update->execute();
}

// Verifica se l’utente è il creatore del torneo
$resCheck = $conn->query("SELECT id_utente, nome FROM tornei WHERE Id_torneo = $id_torneo");
$torneo = $resCheck->fetch_assoc();
$isCreatore = $torneo && $torneo['id_utente'] == $id_utente;
$nome_torneo = $torneo['nome'] ?? "Torneo";

// Recupera partite
$partite = [];
$res = $conn->query("SELECT p.*, s1.nome AS squadra1, s2.nome AS squadra2 
                     FROM partite p
                     JOIN squadre s1 ON p.id_squadra1 = s1.Id_squadra
                     JOIN squadre s2 ON p.id_squadra2 = s2.Id_squadra
                     WHERE p.id_torneo = $id_torneo
                     ORDER BY p.data_partita IS NULL, p.data_partita ASC, p.orario ASC");

while ($row = $res->fetch_assoc()) {
    $partite[] = $row;
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Calendario - <?= htmlspecialchars($nome_torneo) ?></title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f1f5f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #1976D2;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ccc;
        }
        th {
            background-color: #e3f2fd;
        }
        .btn {
            padding: 6px 12px;
            background-color: #1976D2;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0D47A1;
        }
        input[type="number"] {
            width: 50px;
            padding: 5px;
            text-align: center;
        }
        .back {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>📖 Calendario - <?= htmlspecialchars($nome_torneo) ?></h1>

    <?php if (empty($partite)): ?>
        <p style="text-align: center;">Nessuna partita trovata per questo torneo.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>#</th>
                <th>Squadra 1</th>
                <th>Risultato</th>
                <th>Squadra 2</th>
                <th>Data</th>
                <th>Ora</th>
                <?php if ($isCreatore): ?><th>Azioni</th><?php endif; ?>
            </tr>

            <?php foreach ($partite as $i => $p): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= htmlspecialchars($p['squadra1']) ?></td>
                    <td>
                        <?php if ($isCreatore): ?>
                            <form method="POST" style="display: flex; justify-content: center; gap: 5px;">
                                <input type="hidden" name="id_partita" value="<?= $p['id_partita'] ?>">
                                <input type="number" name="gol_1" min="0" value="<?= $p['gol_1'] ?>" required>
                                <span>-</span>
                                <input type="number" name="gol_2" min="0" value="<?= $p['gol_2'] ?>" required>
                        <?php else: ?>
                            <?= $p['gol_1'] ?> - <?= $p['gol_2'] ?>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($p['squadra2']) ?></td>
                    <td><?= $p['data_partita'] ?? '-' ?></td>
                    <td><?= $p['orario'] ?? '-' ?></td>
                    <?php if ($isCreatore): ?>
                        <td>
                            <button type="submit" name="salva_risultato" class="btn">Salva</button>
                            </form>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <div class="back">
        <a href="index.php" class="btn">🏠 Torna alla Home</a>
    </div>
</div>

</body>
</html>

