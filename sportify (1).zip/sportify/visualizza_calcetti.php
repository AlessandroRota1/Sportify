<?php
session_start();

// Controllo accesso
if (!isset($_SESSION['id_utente'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "sportify";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connessione fallita: " . $conn->connect_error);

$id_utente = $_SESSION['id_utente'];
$messaggio = "";

// Gestione unione al calcetto
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['unisciti'])) {
    $id_calcetto = (int)$_POST['id_calcetto'];

    $resC = $conn->query("SELECT id_utente FROM calcetti WHERE id_calcetto = $id_calcetto");
    if ($rowC = $resC->fetch_assoc()) {
        if ($rowC['id_utente'] == $id_utente) {
            $messaggio = "Non puoi unirti a un calcetto che hai creato.";
        } else {
            $resV = $conn->query("SELECT 1 FROM calcetto_utente WHERE id_calcetto = $id_calcetto AND id_utente = $id_utente");
            if ($resV->num_rows) {
                $messaggio = "Sei già iscritto a questo calcetto!";
            } else {
                $resP = $conn->query("
                    SELECT c.posti_occupati, ca.n_giocatori
                    FROM calcetti c
                    JOIN campi ca ON c.id_campo = ca.id_campo
                    WHERE c.id_calcetto = $id_calcetto
                ");
                if ($rowP = $resP->fetch_assoc()) {
                    $posti = $rowP['posti_occupati'];
                    $capacity = $rowP['n_giocatori'] * 2;
                    if ($posti < $capacity) {
                        $conn->query("INSERT INTO calcetto_utente (id_calcetto, id_utente) VALUES ($id_calcetto, $id_utente)");
                        $conn->query("UPDATE calcetti SET posti_occupati = posti_occupati + 1 WHERE id_calcetto = $id_calcetto");
                        $messaggio = "Ti sei unito al calcetto con successo!";
                    } else {
                        $messaggio = "Il calcetto è già completo ($capacity giocatori).";
                    }
                } else {
                    $messaggio = "Errore nel recupero dei posti.";
                }
            }
        }
    }
}

// Recupero lista calcetti
$resCalc = $conn->query("
    SELECT c.id_calcetto, c.data_ora, ca.indirizzo, c.posti_occupati, ca.n_giocatori
    FROM calcetti c
    JOIN campi ca ON c.id_campo = ca.id_campo
    WHERE c.visibilita = 1
    ORDER BY c.data_ora ASC
");
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Visualizza Calcetti</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; margin: 0; padding: 0; }
        .container { width: 60%; margin: 30px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h1 { text-align: center; }
        .message { text-align: center; color: green; margin-bottom: 15px; }
        .calcetto-item { background: #e9e9e9; margin-bottom: 20px; padding: 15px; border-radius: 5px; }
        .calcetto-header { display: flex; justify-content: space-between; align-items: center; }
        .calcetto-header h3 { margin: 0; }
        .info-btn, .btn { background: #4CAF50; color: #fff; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; }
        .info-btn:hover, .btn:hover { background: #388e3c; }
        .info-section { background: #f0f0f0; padding: 10px; margin-top: 10px; border-radius: 4px; display: none; }
        .info-section ul { list-style: none; padding: 0; }
        a.home { display: inline-block; margin-bottom: 20px; text-decoration: none; background: #1976D2; color: #fff; padding: 8px 12px; border-radius: 4px; }
        a.home:hover { background: #0D47A1; }
        .iscritto { font-weight: bold; color: #4CAF50; margin-left: 10px; }
        .chat-btn { background: #2196F3; margin-left: 10px; }
        .chat-btn:hover { background: #1565C0; }
    </style>
    <script>
        function toggleInfo(id) {
            const section = document.getElementById('info-' + id);
            section.style.display = (section.style.display === 'block') ? 'none' : 'block';
        }
    </script>
</head>
<body>
    <div class="container">
        <a href="index.php" class="home">🏠 Torna alla Home</a>
        <h1>Calcetti Disponibili</h1>
        <?php if ($messaggio): ?><p class="message"><?= $messaggio ?></p><?php endif; ?>

        <?php if ($resCalc->num_rows): ?>
            <?php while ($c = $resCalc->fetch_assoc()):
                $capacity = $c['n_giocatori'] * 2;
                $id_calcetto = $c['id_calcetto'];

                // Controllo iscrizione
                $iscritto = $conn->query("
                    SELECT 1 FROM calcetto_utente 
                    WHERE id_calcetto = $id_calcetto AND id_utente = $id_utente
                ")->num_rows > 0;
            ?>
                <div class="calcetto-item">
                    <div class="calcetto-header">
                        <h3><?= htmlspecialchars($c['indirizzo']) ?> — <?= $c['data_ora'] ?></h3>
                        <div>
                            <?php if (!$iscritto): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="id_calcetto" value="<?= $id_calcetto ?>">
                                    <button class="btn" name="unisciti">Unisciti</button>
                                </form>
                            <?php else: ?>
                                <span class="iscritto">✅ Sei iscritto</span>
                                <a href="chat.php?id_calcetto=<?= $id_calcetto ?>" class="btn chat-btn">💬 Chat</a>
                            <?php endif; ?>
                            <button class="info-btn" onclick="toggleInfo(<?= $id_calcetto ?>)">Mostra Info</button>
                        </div>
                    </div>
                    <p>Posti occupati: <?= $c['posti_occupati'] ?> / <?= $capacity ?></p>

                    <div class="info-section" id="info-<?= $id_calcetto ?>">
                        <?php
                        $resP = $conn->query("
                            SELECT u.nome, u.cognome, u.id_utente,
                                   CASE WHEN u.id_utente = c.id_utente THEN 1 ELSE 0 END AS is_creatore
                            FROM (
                                SELECT id_utente, id_calcetto FROM calcetto_utente
                                UNION
                                SELECT id_utente, id_calcetto FROM calcetti
                            ) cu
                            JOIN utenti u ON cu.id_utente = u.id_utente
                            JOIN calcetti c ON cu.id_calcetto = c.id_calcetto
                            WHERE cu.id_calcetto = $id_calcetto
                        ");
                        echo '<h4>Partecipanti:</h4>';
                        if ($resP->num_rows) {
                            echo '<ul>';
                            while ($p = $resP->fetch_assoc()) {
                                echo '<li>' . htmlspecialchars($p['nome'] . ' ' . $p['cognome']);
                                if ($p['is_creatore']) echo ' <strong>(Admin)</strong>';
                                echo '</li>';
                            }
                            echo '</ul>';
                        } else {
                            echo '<p>Nessun partecipante.</p>';
                        }

                        $resD = $conn->query("
                            SELECT ca.indirizzo, ca.n_giocatori, c.data_ora, c.posti_occupati, ca.terreno, ca.spogliatoi, ca.docce
                            FROM calcetti c
                            JOIN campi ca ON c.id_campo = ca.id_campo
                            WHERE c.id_calcetto = $id_calcetto
                        ");
                        if ($d = $resD->fetch_assoc()) {
                            echo '<h4>Dettagli:</h4><ul>';
                            echo '<li><strong>Terreno:</strong> ' . htmlspecialchars($d['terreno']) . '</li>';
                            echo '<li><strong>Spogliatoi:</strong> ' . ($d['spogliatoi'] ? 'Sì' : 'No') . '</li>';
                            echo '<li><strong>Docce:</strong> ' . ($d['docce'] ? 'Sì' : 'No') . '</li>';
                            echo '<li><strong>Data/Ora:</strong> ' . $d['data_ora'] . '</li>';
                            echo '<li><strong>Posti occupati:</strong> ' . $d['posti_occupati'] . ' / ' . ($d['n_giocatori'] * 2) . '</li>';
                            echo '</ul>';
                        }
                        ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Non ci sono calcetti disponibili al momento.</p>
        <?php endif; ?>
    </div>
    <?php $conn->close(); ?>
</body>
</html>
