<?php
session_start();

// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$messaggio = "";

// Se il form è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera i dati dal form
    $nome = mysqli_real_escape_string($conn, $_POST['nome']);
    $data_inizio = mysqli_real_escape_string($conn, $_POST['data_inizio']);
    $data_fine = mysqli_real_escape_string($conn, $_POST['data_fine']);
    $ora_inizio = mysqli_real_escape_string($conn, $_POST['ora_inizio']);
    $ora_fine = mysqli_real_escape_string($conn, $_POST['ora_fine']);
    $certificato_medico = (int)$_POST['certificato_medico'];
    $docce = (int)$_POST['docce'];
    $note = mysqli_real_escape_string($conn, $_POST['note']);
    $tipologia = mysqli_real_escape_string($conn, $_POST['tipologia']);
    $max_squadre = (int)$_POST['max_squadre'];
    $max_giocatori = (int)$_POST['max_giocatori'];
    $id_utente = $_SESSION['id_utente'];

    // Query per inserire il torneo
    $sql = "INSERT INTO tornei 
            (nome, data_inizio, data_fine, ora_inizio, ora_fine, certificato_medico, docce, note, tipologia, id_utente, max_squadre, max_giocatori) 
            VALUES 
            ('$nome', '$data_inizio', '$data_fine', '$ora_inizio', '$ora_fine', '$certificato_medico', '$docce', '$note', '$tipologia', '$id_utente', '$max_squadre', '$max_giocatori')";

    if ($conn->query($sql) === TRUE) {
        $id_torneo = $conn->insert_id;
        $messaggio = "Torneo creato con successo!";

        if (isset($_POST['campi']) && !empty($_POST['campi'])) {
            foreach ($_POST['campi'] as $id_campo) {
                $sqlCampoTorneo = "INSERT INTO campo_torneo (id_campo, id_torneo) VALUES ('$id_campo', '$id_torneo')";
                $conn->query($sqlCampoTorneo);
            }
        }
    } else {
        $messaggio = "Errore durante la creazione del torneo: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Crea Torneo - Sportify</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            margin-top: 30px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="date"],
        input[type="time"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"],
        .btn-home {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            text-decoration: none;
            text-align: center;
            display: inline-block;
        }
        input[type="submit"]:hover,
        .btn-home:hover {
            background-color: #45a049;
        }
        .message {
            text-align: center;
            margin-bottom: 15px;
            color: green;
        }
    </style>
</head>
<body>

    <div class="container">

        <!-- Bottone Home -->
        <a href="index.php" class="btn-home">🏠 Torna alla Home</a>

        <h1>Crea un nuovo Torneo</h1>

        <?php if (!empty($messaggio)) echo "<p class='message'>$messaggio</p>"; ?>

        <form action="aggiungi_torneo.php" method="POST">
            <div class="form-group">
                <label for="nome">Nome Torneo:</label>
                <input type="text" id="nome" name="nome" required>
            </div>

            <div class="form-group">
                <label for="data_inizio">Data di Inizio:</label>
                <input type="date" id="data_inizio" name="data_inizio" required>
            </div>

            <div class="form-group">
                <label for="data_fine">Data di Fine:</label>
                <input type="date" id="data_fine" name="data_fine" required>
            </div>

            <div class="form-group">
                <label for="ora_inizio">Ora di Inizio:</label>
                <input type="time" id="ora_inizio" name="ora_inizio" required>
            </div>

            <div class="form-group">
                <label for="ora_fine">Ora di Fine:</label>
                <input type="time" id="ora_fine" name="ora_fine" required>
            </div>

            <div class="form-group">
                <label for="certificato_medico">Certificato Medico Obbligatorio:</label>
                <select id="certificato_medico" name="certificato_medico" required>
                    <option value="1">Sì</option>
                    <option value="0">No</option>
                </select>
            </div>

            <div class="form-group">
                <label for="docce">Docce Disponibili:</label>
                <select id="docce" name="docce" required>
                    <option value="1">Sì</option>
                    <option value="0">No</option>
                </select>
            </div>

            <div class="form-group">
                <label for="note">Note:</label>
                <textarea id="note" name="note"></textarea>
            </div>

            <div class="form-group">
                <label for="tipologia">Tipologia Torneo:</label>
                <select id="tipologia" name="tipologia" required>
                <option value="Girone Unico">Girone Unico</option>
                <option value="Gironi Multipli">Gironi Multipli</option>
                <option value="Eliminazione Diretta">Eliminazione Diretta</option>
                </select>
            </div>


            <div class="form-group">
                <label for="max_squadre">Numero massimo di squadre:</label>
                <input type="number" id="max_squadre" name="max_squadre" min="2" max="64" value="16" required>
            </div>

            <div class="form-group">
                <label for="max_giocatori">Numero massimo di giocatori per squadra:</label>
                <input type="number" id="max_giocatori" name="max_giocatori" min="1" max="30" value="11" required>
            </div>

            <div class="form-group">
                <label for="campi">Seleziona uno o più campi:</label>
                <select id="campi" name="campi[]" multiple required>
                    <?php
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    $sqlCampi = "SELECT id_campo, indirizzo FROM campi";
                    $resultCampi = $conn->query($sqlCampi);

                    if ($resultCampi && $resultCampi->num_rows > 0) {
                        while ($campo = $resultCampi->fetch_assoc()) {
                            echo '<option value="' . $campo['id_campo'] . '">' . htmlspecialchars($campo['indirizzo']) . '</option>';
                        }
                    } else {
                        echo '<option value="">Nessun campo disponibile</option>';
                    }
                    $conn->close();
                    ?>
                </select>
            </div>

            <input type="submit" value="Crea Torneo">
        </form>
    </div>

</body>
</html>
