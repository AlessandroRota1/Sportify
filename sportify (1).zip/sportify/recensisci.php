<?php
session_start();
if (!isset($_SESSION['id_utente'])) {
    header('Location: login.php');
    exit();
}

// Connessione al DB
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$messaggio = "";

// Gestione POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type'], $_POST['valutazione'], $_POST['commento'])) {
    $type           = $_POST['type'];            // "campo" o "calcetto"
    $valutazione    = (int)$_POST['valutazione'];
    $commento       = $conn->real_escape_string($_POST['commento']);
    $id_utente      = (int)$_SESSION['id_utente'];
    $data_rec       = date('Y-m-d');

    // Determino i campi
    $id_campo    = $type === 'campo'    ? (int)$_POST['id_campo']    : 'NULL';
    $id_calcetto = $type === 'calcetto' ? (int)$_POST['id_calcetto'] : 'NULL';

    $sql = "INSERT INTO recensioni
            (valutazione, commento, data_recensione, id_utente, id_campo, id_calcetto)
            VALUES
            ($valutazione, '$commento', '$data_rec', $id_utente, $id_campo, $id_calcetto)";

    if ($conn->query($sql)) {
        $messaggio = "Recensione salvata con successo!";
    } else {
        $messaggio = "Errore: " . $conn->error;
    }
}

// Recupero liste per i select
$campi    = $conn->query("SELECT id_campo, indirizzo FROM campi");
$calcetti = $conn->query("
    SELECT c.id_calcetto, ca.indirizzo, c.data_ora
    FROM calcetti c
    JOIN campi ca ON c.id_campo = ca.id_campo
    ORDER BY c.data_ora ASC
");

// Recupero tutte le recensioni
$recRes = $conn->query("
    SELECT r.*, u.nome, u.cognome,
           c.indirizzo AS campo_indirizzo,
           CONCAT(ca.indirizzo, ' - ', DATE_FORMAT(cal.data_ora,'%Y-%m-%d %H:%i')) AS calcetto_descr
    FROM recensioni r
    JOIN utenti u ON r.id_utente = u.id_utente
    LEFT JOIN campi c ON r.id_campo = c.id_campo
    LEFT JOIN calcetti cal ON r.id_calcetto = cal.id_calcetto
    LEFT JOIN campi ca ON cal.id_campo = ca.id_campo
    ORDER BY r.data_recensione DESC
");

$conn->close();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Recensioni - Sportify</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f4f4f4; margin:0; padding:20px; }
        .container { max-width:800px; margin:auto; background:white; padding:20px; border-radius:8px;
                     box-shadow:0 0 10px rgba(0,0,0,0.1); }
        h1, h2 { text-align:center; color:#1976D2; }
        .message { text-align:center; color:green; margin-bottom:15px; }
        form { margin-bottom:30px; }
        .form-group { margin-bottom:15px; }
        label { display:block; font-weight:bold; margin-bottom:5px; }
        select, textarea { width:100%; padding:8px; border:1px solid #ccc; border-radius:4px; box-sizing:border-box; }
        textarea { resize:vertical; height:80px; }
        input[type="submit"], .btn-home, .btn-logout {
            padding:8px 12px; background:#4CAF50; color:white; border:none; border-radius:4px;
            cursor:pointer; text-decoration:none; display:inline-block; margin-top:10px;
        }
        input[type="submit"]:hover, .btn-home:hover, .btn-logout:hover { background:#45a049; }
        table { width:100%; border-collapse:collapse; margin-top:20px; }
        th, td { padding:8px; border:1px solid #ddd; text-align:left; }
        th { background:#e3f2fd; }
        .tipo { font-style:italic; color:#555; }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="btn-home">🏠 Home</a>
        <a href="logout.php" class="btn-logout">🚪 Logout</a>

        <h1>Recensioni</h1>
        <?php if ($messaggio): ?><p class="message"><?= $messaggio ?></p><?php endif; ?>

        <!-- FORM: Recensisci un Campo -->
        <h2>Recensisci un Campo</h2>
        <form method="POST">
            <input type="hidden" name="type" value="campo">
            <div class="form-group">
                <label for="id_campo">Seleziona Campo:</label>
                <select id="id_campo" name="id_campo" required>
                    <option value="">-- Scegli --</option>
                    <?php while ($r = $campi->fetch_assoc()): ?>
                        <option value="<?= $r['id_campo'] ?>">
                            <?= htmlspecialchars($r['indirizzo']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="valutazione">Valutazione (1–5):</label>
                <select id="valutazione" name="valutazione" required>
                    <option value="">-- Scegli --</option>
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <option value="<?= $i ?>"><?= $i ?> <?= $i===1?'stella':'stelle' ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="commento">Commento:</label>
                <textarea id="commento" name="commento" required></textarea>
            </div>
            <input type="submit" value="Invia Recensione">
        </form>

        <!-- FORM: Recensisci un Calcetto -->
        <h2>Recensisci un Calcetto</h2>
        <form method="POST">
            <input type="hidden" name="type" value="calcetto">
            <div class="form-group">
                <label for="id_calcetto">Seleziona Calcetto:</label>
                <select id="id_calcetto" name="id_calcetto" required>
                    <option value="">-- Scegli --</option>
                    <?php while ($r = $calcetti->fetch_assoc()): ?>
                        <option value="<?= $r['id_calcetto'] ?>">
                            <?= htmlspecialchars($r['indirizzo']) ?> —
                            <?= $r['data_ora'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="valutazione2">Valutazione (1–5):</label>
                <select id="valutazione2" name="valutazione" required>
                    <option value="">-- Scegli --</option>
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <option value="<?= $i ?>"><?= $i ?> <?= $i===1?'stella':'stelle' ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="commento2">Commento:</label>
                <textarea id="commento2" name="commento" required></textarea>
            </div>
            <input type="submit" value="Invia Recensione">
        </form>

        <!-- ELENCO RECENSIONI -->
        <h2>Tutte le Recensioni</h2>
        <?php if ($recRes->num_rows): ?>
            <table>
                <tr>
                    <th>Tipo</th>
                    <th>Target</th>
                    <th>Utente</th>
                    <th>Valutazione</th>
                    <th>Commento</th>
                    <th>Data</th>
                </tr>
                <?php while ($r = $recRes->fetch_assoc()): ?>
                    <tr>
                        <td class="tipo">
                            <?= $r['id_campo'] ? 'Campo' : 'Calcetto' ?>
                        </td>
                        <td>
                            <?= $r['id_campo']
                                ? htmlspecialchars($r['campo_indirizzo'])
                                : htmlspecialchars($r['calcetto_descr']);
                            ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($r['nome'] . ' ' . $r['cognome']) ?>
                        </td>
                        <td>⭐ <?= $r['valutazione'] ?>/5</td>
                        <td><?= nl2br(htmlspecialchars($r['commento'])) ?></td>
                        <td><?= $r['data_recensione'] ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>Nessuna recensione disponibile.</p>
        <?php endif; ?>
    </div>
</body>
</html>
