<?php
session_start();
if (!isset($_SESSION['id_utente'])) {
    header('Location: login.php');
    exit();
}

// Parametro pre-selezionato (da GET o da POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['campo'])) {
    $id_campo_selezionato = (int)$_POST['campo'];
} else {
    $id_campo_selezionato = isset($_GET['id_campo']) ? (int)$_GET['id_campo'] : null;
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$messaggio = "";

// Se arrivo in POST, inserisco il calcetto
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data_ora    = $conn->real_escape_string($_POST['data_ora']);
    $visibilita  = (int)$_POST['visibilita'];
    $id_utente   = (int)$_SESSION['id_utente'];
    $id_campo    = (int)$_POST['campo'];

    // Il creatore è già conteggiato nel posti_occupati iniziali
    $posti_occupati = 1;

    $sql = "
        INSERT INTO calcetti 
          (id_campo, data_ora, posti_occupati, visibilita, id_utente)
        VALUES
          ($id_campo, '$data_ora', $posti_occupati, $visibilita, $id_utente)
    ";
    if ($conn->query($sql) === TRUE) {
        $messaggio = "✅ Calcetto creato con successo!";
        // Dopo creazione, faccio sparire la selezione
        $id_campo_selezionato = null;
    } else {
        $messaggio = "❌ Errore durante la creazione: " . $conn->error;
    }
}

// Prelevo tutti i campi per la select
$sqlCampi   = "SELECT id_campo, indirizzo FROM campi";
$resultCampi = $conn->query($sqlCampi);

$conn->close();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crea un Calcetto - Sportify</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin:0; padding:0; }
        .container {
            max-width: 500px; margin: 40px auto; background: white;
            padding: 20px; border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 { text-align: center; color: #1976D2; margin-bottom: 20px; }
        .message { text-align: center; margin-bottom: 15px; color: green; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        input[type="datetime-local"],
        select {
            width: 100%; padding: 10px; border: 1px solid #ccc;
            border-radius: 5px; box-sizing: border-box;
        }
        input[type="submit"],
        .btn-home {
            width: 100%; padding: 10px;
            background: #4CAF50; color: white;
            border: none; border-radius: 5px;
            cursor: pointer; text-decoration: none;
            display: inline-block; text-align: center;
            font-size: 1rem;
            transition: background 0.3s;
        }
        input[type="submit"]:hover,
        .btn-home:hover { background: #45a049; }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="btn-home">🏠 Torna alla Home</a>
        <h1>Crea un nuovo Calcetto</h1>

        <?php if ($messaggio): ?>
            <p class="message"><?= htmlspecialchars($messaggio) ?></p>
        <?php endif; ?>

        <form action="aggiungi_calcetto.php" method="POST">
            <div class="form-group">
                <label for="data_ora">Data e Ora:</label>
                <input type="datetime-local" id="data_ora" name="data_ora" required>
            </div>

            <div class="form-group">
                <label for="campo">Seleziona il campo:</label>
                <select id="campo" name="campo" required>
                    <option value="">-- Scegli un campo --</option>
                    <?php if ($resultCampi && $resultCampi->num_rows): ?>
                        <?php while ($c = $resultCampi->fetch_assoc()): ?>
                            <option value="<?= $c['id_campo'] ?>"
                                <?= $c['id_campo'] === $id_campo_selezionato ? 'selected' : '' ?>>
                                <?= htmlspecialchars($c['indirizzo']) ?>
                            </option>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <option value="">Nessun campo disponibile</option>
                    <?php endif; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="visibilita">Visibilità:</label>
                <select id="visibilita" name="visibilita" required>
                    <option value="1">Pubblico</option>
                    <option value="0">Privato</option>
                </select>
            </div>

            <input type="submit" value="Crea Calcetto">
        </form>
    </div>
</body>
</html>
