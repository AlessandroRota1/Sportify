<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sportify";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connessione fallita: " . $conn->connect_error);

$id_utente = $_SESSION['id_utente'] ?? 0;
$oggi = date('Y-m-d H:i:s');

// === CALCETTI ===
$calcetti_futuri = [];
$calcetti_passati = [];

$sql = "
    SELECT c.*, ca.indirizzo, 
           CASE WHEN c.id_utente = $id_utente THEN 'Organizzatore' ELSE 'Partecipante' END AS ruolo
    FROM calcetti c
    JOIN campi ca ON c.id_campo = ca.id_campo
    LEFT JOIN calcetto_utente cu ON cu.id_calcetto = c.id_calcetto
    WHERE c.id_utente = $id_utente OR cu.id_utente = $id_utente
    GROUP BY c.id_calcetto
    ORDER BY c.data_ora ASC
";
$res = $conn->query($sql);
while ($row = $res->fetch_assoc()) {
    if ($row['data_ora'] >= $oggi) {
        $calcetti_futuri[] = $row;
    } else {
        $calcetti_passati[] = $row;
    }
}

// === TORNEI ===
$tornei_futuri = [];
$tornei_passati = [];

$sql = "
    SELECT t.*, s.nome AS squadra_nome
    FROM tornei t
    JOIN squadre s ON s.id_torneo = t.Id_torneo
    JOIN utente_squadra us ON us.id_squadra = s.Id_squadra
    WHERE us.id_utente = $id_utente
";
$res = $conn->query($sql);
while ($row = $res->fetch_assoc()) {
    if ($row['data_fine'] >= date('Y-m-d')) {
        $tornei_futuri[] = $row;
    } else {
        $tornei_passati[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>I miei impegni</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f1f5f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #1976D2;
        }
        h2 {
            margin-top: 40px;
            color: #0D47A1;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            text-align: center;
        }
        th {
            background-color: #e3f2fd;
        }
        .btn {
            padding: 6px 12px;
            background-color: #1976D2;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            margin: 10px 0;
        }
        .btn:hover {
            background-color: #0D47A1;
        }
        .top-buttons {
            text-align: right;
            margin-bottom: 20px;
        }
        .storico {
            display: none;
        }
    </style>
    <script>
        function toggleStorico(section) {
            const blocco = document.getElementById(section);
            blocco.style.display = (blocco.style.display === 'none' || blocco.style.display === '') ? 'block' : 'none';
        }
    </script>
</head>
<body>

<div class="container">
    <div class="top-buttons">
        <a href="index.php" class="btn">🏠 Home</a>
        <a href="logout.php" class="btn" style="background-color:#e74c3c;">🚪 Logout</a>
    </div>

    <h1>📅 I miei impegni programmati</h1>

    <h2>👟 Calcetti Futuri</h2>
    <?php if (empty($calcetti_futuri)): ?>
        <p>Nessun calcetto futuro.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Data e ora</th>
                <th>Campo</th>
                <th>Ruolo</th>
                <th>Visibilità</th>
            </tr>
            <?php foreach ($calcetti_futuri as $c): ?>
                <tr>
                    <td><?= $c['data_ora'] ?></td>
                    <td><?= htmlspecialchars($c['indirizzo']) ?></td>
                    <td><?= $c['ruolo'] ?></td>
                    <td><?= $c['visibilita'] ? 'Pubblico' : 'Privato' ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <button class="btn" onclick="toggleStorico('storico-calcetti')">📜 Visualizza Storico Calcetti</button>
    <div id="storico-calcetti" class="storico">
        <h2>📜 Storico Calcetti</h2>
        <?php if (empty($calcetti_passati)): ?>
            <p>Nessun calcetto passato.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Data e ora</th>
                    <th>Campo</th>
                    <th>Ruolo</th>
                    <th>Visibilità</th>
                </tr>
                <?php foreach ($calcetti_passati as $c): ?>
                    <tr>
                        <td><?= $c['data_ora'] ?></td>
                        <td><?= htmlspecialchars($c['indirizzo']) ?></td>
                        <td><?= $c['ruolo'] ?></td>
                        <td><?= $c['visibilita'] ? 'Pubblico' : 'Privato' ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

    <h2>🏆 Tornei Attivi</h2>
    <?php if (empty($tornei_futuri)): ?>
        <p>Non sei iscritto a tornei futuri.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Nome Torneo</th>
                <th>Periodo</th>
                <th>Squadra</th>
                <th>Azioni</th>
            </tr>
            <?php foreach ($tornei_futuri as $t): ?>
                <tr>
                    <td><?= htmlspecialchars($t['nome']) ?></td>
                    <td><?= $t['data_inizio'] ?> - <?= $t['data_fine'] ?></td>
                    <td><?= htmlspecialchars($t['squadra_nome']) ?></td>
                    <td>
                        <a href="mostra_calendario.php?id_torneo=<?= $t['Id_torneo'] ?>" class="btn">📖 Calendario</a>
                        <a href="mostra_classifica.php?id_torneo=<?= $t['Id_torneo'] ?>" class="btn">📊 Classifica</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <button class="btn" onclick="toggleStorico('storico-tornei')">📜 Visualizza Storico Tornei</button>
    <div id="storico-tornei" class="storico">
        <h2>📜 Storico Tornei</h2>
        <?php if (empty($tornei_passati)): ?>
            <p>Nessun torneo concluso.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Nome Torneo</th>
                    <th>Periodo</th>
                    <th>Squadra</th>
                    <th>Azioni</th>
                </tr>
                <?php foreach ($tornei_passati as $t): ?>
                    <tr>
                        <td><?= htmlspecialchars($t['nome']) ?></td>
                        <td><?= $t['data_inizio'] ?> - <?= $t['data_fine'] ?></td>
                        <td><?= htmlspecialchars($t['squadra_nome']) ?></td>
                        <td>
                            <a href="mostra_calendario.php?id_torneo=<?= $t['Id_torneo'] ?>" class="btn">📖 Calendario</a>
                            <a href="mostra_classifica.php?id_torneo=<?= $t['Id_torneo'] ?>" class="btn">📊 Classifica</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

</div>

</body>
</html>
