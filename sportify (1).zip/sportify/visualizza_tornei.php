<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$messaggio = "";

// Creazione squadra con controllo su max_squadre
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['unisciti_squadra'])) {
    $id_torneo = (int)$_POST['id_torneo'];
    $id_utente = $_SESSION['id_utente'];
    $nome_squadra = mysqli_real_escape_string($conn, $_POST['nome_squadra']);

    // 1. Verifica se ha già creato una squadra in questo torneo
    $verifica = $conn->query("SELECT * FROM squadre WHERE id_torneo = $id_torneo AND id_creatore = $id_utente");
    if ($verifica->num_rows > 0) {
        $messaggio = "Hai già creato una squadra per questo torneo.";
    } else {
        // 2. Verifica max squadre
        $check_sql = "
            SELECT 
                (SELECT COUNT(*) FROM squadre WHERE id_torneo = $id_torneo) AS squadre_attuali,
                t.max_squadre
            FROM tornei t
            WHERE t.Id_torneo = $id_torneo
        ";
        $res_check = $conn->query($check_sql);
        $row = $res_check->fetch_assoc();

        if ($row['squadre_attuali'] >= $row['max_squadre']) {
            $messaggio = "Il numero massimo di squadre per questo torneo è stato raggiunto.";
        } else {
            // 3. Crea squadra
            $sqlSquadra = "INSERT INTO squadre (nome, id_torneo, id_creatore) VALUES ('$nome_squadra', '$id_torneo', '$id_utente')";
            if ($conn->query($sqlSquadra) === TRUE) {
                $id_squadra = $conn->insert_id;
                $sqlUtenteSquadra = "INSERT INTO utente_squadra (id_utente, id_squadra) VALUES ('$id_utente', '$id_squadra')";
                if ($conn->query($sqlUtenteSquadra) === TRUE) {
                    $messaggio = "Sei stato aggiunto alla squadra con successo!";
                } else {
                    $messaggio = "Errore durante l'iscrizione alla squadra: " . $conn->error;
                }
            } else {
                $messaggio = "Errore durante la creazione della squadra: " . $conn->error;
            }
        }
    }
}


// Recupera tornei e campi associati
$sqlTornei = "SELECT t.id_torneo, t.nome, t.data_inizio, t.data_fine, t.tipologia, t.note, t.certificato_medico, t.docce, t.ora_inizio, t.ora_fine, t.max_squadre, c.indirizzo 
              FROM tornei t
              JOIN campo_torneo ct ON t.id_torneo = ct.id_torneo
              JOIN campi c ON ct.id_campo = c.id_campo";

$resultTornei = $conn->query($sqlTornei);

$tornei = [];
while ($row = $resultTornei->fetch_assoc()) {
    $id = $row['id_torneo'];
    if (!isset($tornei[$id])) {
        $tornei[$id] = [
            'nome' => $row['nome'],
            'data_inizio' => $row['data_inizio'],
            'data_fine' => $row['data_fine'],
            'tipologia' => $row['tipologia'],
            'note' => $row['note'],
            'certificato_medico' => $row['certificato_medico'],
            'docce' => $row['docce'],
            'ora_inizio' => $row['ora_inizio'],
            'ora_fine' => $row['ora_fine'],
            'max_squadre' => $row['max_squadre'],
            'campi' => [],
        ];
    }
    $tornei[$id]['campi'][] = $row['indirizzo'];
}
$conn->close();

// Squadre create dall’utente
$conn2 = new mysqli($servername, $username, $password, $dbname);
$squadre_utente = [];
$res = $conn2->query("SELECT id_torneo FROM squadre WHERE id_creatore = " . $_SESSION['id_utente']);
while ($row = $res->fetch_assoc()) {
    $squadre_utente[] = $row['id_torneo'];
}
$conn2->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Visualizza Tornei - Sportify</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #e3f2fd, #ffffff);
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            max-width: 900px;
            margin: 40px auto;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #1976D2;
        }
        .top-buttons {
            text-align: right;
            margin-bottom: 20px;
        }
        .btn {
            padding: 10px 15px;
            background-color: #1976D2;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            margin-left: 10px;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0D47A1;
        }
        .btn.logout {
            background-color: #e74c3c;
        }
        .message {
            text-align: center;
            margin: 20px 0;
            color: green;
            font-weight: bold;
        }
        .torneo-item {
            margin-bottom: 25px;
            padding: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            background-color: #f9f9f9;
        }
        .info-extra {
            display: none;
            margin-top: 15px;
            padding: 10px;
            background-color: #e3f2fd;
            border-radius: 6px;
        }
        input[type="text"] {
            padding: 8px;
            margin-top: 10px;
            margin-right: 10px;
            width: 60%;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
    </style>
    <script>
        function toggleInfo(id) {
            const section = document.getElementById('info-' + id);
            section.style.display = (section.style.display === 'block') ? 'none' : 'block';
        }
    </script>
</head>
<body>

<div class="container">
    <div class="top-buttons">
        <a href="index.php" class="btn">🏠 Torna alla Home</a>
        <a href="logout.php" class="btn logout">🚪 Logout</a>
    </div>

    <h1>Tornei Disponibili</h1>

    <?php if (!empty($messaggio)) echo "<p class='message'>$messaggio</p>"; ?>

    <?php foreach ($tornei as $id_torneo => $torneo): ?>
        <div class="torneo-item">
            <h3><?= htmlspecialchars($torneo['nome']) ?></h3>
            <p><strong>Data Inizio:</strong> <?= $torneo['data_inizio'] ?> | <strong>Data Fine:</strong> <?= $torneo['data_fine'] ?></p>

            <button class="btn" onclick="toggleInfo(<?= $id_torneo ?>)">Mostra Info</button>

            <div class="info-extra" id="info-<?= $id_torneo ?>">
                <p><strong>Tipologia:</strong> <?= htmlspecialchars($torneo['tipologia']) ?></p>
                <p><strong>Note:</strong> <?= htmlspecialchars($torneo['note']) ?></p>
                <p><strong>Orario:</strong> <?= htmlspecialchars($torneo['ora_inizio']) ?> - <?= htmlspecialchars($torneo['ora_fine']) ?></p>
                <p><strong>Certificato medico richiesto:</strong> <?= $torneo['certificato_medico'] ? 'Sì' : 'No' ?></p>
                <p><strong>Docce disponibili:</strong> <?= $torneo['docce'] ? 'Sì' : 'No' ?></p>
                <p><strong>Campi associati:</strong></p>
                <ul>
                    <?php foreach ($torneo['campi'] as $campo): ?>
                        <li><?= htmlspecialchars($campo) ?></li>
                    <?php endforeach; ?>
                </ul>

                <?php
                $conn_temp = new mysqli($servername, $username, $password, $dbname);
                $count_sql = "SELECT COUNT(*) as tot FROM squadre WHERE id_torneo = $id_torneo";
                $res = $conn_temp->query($count_sql);
                $row = $res->fetch_assoc();
                $tot_squadre = $row['tot'];
                $conn_temp->close();
                ?>
                <p><strong>Squadre iscritte:</strong> <?= $tot_squadre ?> / <?= $torneo['max_squadre'] ?></p>
            </div>

            <form action="visualizza_tornei.php" method="POST">
                <input type="hidden" name="id_torneo" value="<?= $id_torneo ?>">
                <input type="text" name="nome_squadra" placeholder="Nome della squadra" required>
                <input type="submit" name="unisciti_squadra" value="Crea una squadra" class="btn">
            </form>

            <form action="visualizza_squadre.php" method="GET" style="margin-top: 10px;">
                <input type="hidden" name="id_torneo" value="<?= $id_torneo ?>">
                <input type="submit" value="Unisciti a una squadra" class="btn">
            </form>

            <?php if (in_array($id_torneo, $squadre_utente)): ?>
                <form action="gestisci_richieste.php" method="GET" style="margin-top: 10px;">
                    <input type="hidden" name="id_torneo" value="<?= $id_torneo ?>">
                    <input type="submit" value="Gestisci Richieste" class="btn">
                </form>
            <?php endif; ?>

            <?php
            $conn3 = new mysqli($servername, $username, $password, $dbname);
            $check_partite = $conn3->query("SELECT 1 FROM partite WHERE id_torneo = $id_torneo LIMIT 1");
            $calendario_esiste = $check_partite->num_rows > 0;
            $conn3->close();
            ?>

            <?php if (!$calendario_esiste && in_array($id_torneo, $squadre_utente)): ?>
                <form action="genera_calendario.php" method="GET" style="margin-top: 10px;">
                    <input type="hidden" name="id_torneo" value="<?= $id_torneo ?>">
                    <input type="submit" value="📅 Genera Calendario" class="btn">
                </form>
            <?php elseif ($calendario_esiste): ?>
                <form action="mostra_calendario.php" method="GET" style="margin-top: 10px;">
                    <input type="hidden" name="id_torneo" value="<?= $id_torneo ?>">
                    <input type="submit" value="📖 Mostra Calendario" class="btn">
                </form>
            <?php endif; ?>
            <form action="mostra_classifica.php" method="GET" style="margin-top: 10px;">
    <input type="hidden" name="id_torneo" value="<?= $id_torneo ?>">
    <input type="submit" value="📊 Mostra Classifica" class="btn">
</form>


        </div>
    <?php endforeach; ?>
</div>

</body>
</html>
