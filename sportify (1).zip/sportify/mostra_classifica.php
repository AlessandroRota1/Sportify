<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sportify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connessione fallita: " . $conn->connect_error);

if (!isset($_GET['id_torneo'])) {
    die("Torneo non specificato.");
}

$id_torneo = (int)$_GET['id_torneo'];

// Recupera nome torneo
$resTorneo = $conn->query("SELECT nome FROM tornei WHERE Id_torneo = $id_torneo");
$nome_torneo = $resTorneo->fetch_assoc()['nome'] ?? 'Torneo';

// Recupera squadre del torneo
$squadre = [];
$res = $conn->query("SELECT Id_squadra, nome FROM squadre WHERE id_torneo = $id_torneo");
while ($row = $res->fetch_assoc()) {
    $squadre[$row['Id_squadra']] = [
        'nome' => $row['nome'],
        'giocate' => 0,
        'vittorie' => 0,
        'pareggi' => 0,
        'sconfitte' => 0,
        'punti' => 0,
        'gol_fatti' => 0,
        'gol_subiti' => 0,
        'diff' => 0
    ];
}

// Calcola statistiche da partite giocate
$resPartite = $conn->query("SELECT * FROM partite WHERE id_torneo = $id_torneo AND gol_1 IS NOT NULL AND gol_2 IS NOT NULL");
while ($p = $resPartite->fetch_assoc()) {
    $s1 = $p['id_squadra1'];
    $s2 = $p['id_squadra2'];
    $g1 = $p['gol_1'];
    $g2 = $p['gol_2'];

    // Aggiorna partite giocate
    $squadre[$s1]['giocate']++;
    $squadre[$s2]['giocate']++;

    // Gol fatti e subiti
    $squadre[$s1]['gol_fatti'] += $g1;
    $squadre[$s1]['gol_subiti'] += $g2;
    $squadre[$s2]['gol_fatti'] += $g2;
    $squadre[$s2]['gol_subiti'] += $g1;

    // Punti e W/D/L
    if ($g1 > $g2) {
        $squadre[$s1]['vittorie']++;
        $squadre[$s1]['punti'] += 3;
        $squadre[$s2]['sconfitte']++;
    } elseif ($g2 > $g1) {
        $squadre[$s2]['vittorie']++;
        $squadre[$s2]['punti'] += 3;
        $squadre[$s1]['sconfitte']++;
    } else {
        $squadre[$s1]['pareggi']++;
        $squadre[$s2]['pareggi']++;
        $squadre[$s1]['punti'] += 1;
        $squadre[$s2]['punti'] += 1;
    }
}

// Calcola differenza reti
foreach ($squadre as &$s) {
    $s['diff'] = $s['gol_fatti'] - $s['gol_subiti'];
}

// Ordina classifica
usort($squadre, function ($a, $b) {
    if ($a['punti'] != $b['punti']) return $b['punti'] - $a['punti'];
    if ($a['diff'] != $b['diff']) return $b['diff'] - $a['diff'];
    return $b['gol_fatti'] - $a['gol_fatti'];
});
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Classifica - <?= htmlspecialchars($nome_torneo) ?></title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f1f5f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #1976D2;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ccc;
        }
        th {
            background-color: #e3f2fd;
        }
        .btn {
            display: inline-block;
            padding: 10px 15px;
            background-color: #1976D2;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            margin-top: 20px;
        }
        .btn:hover {
            background-color: #0D47A1;
        }
        .back {
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>📊 Classifica - <?= htmlspecialchars($nome_torneo) ?></h1>

    <table>
        <tr>
            <th>Pos</th>
            <th>Squadra</th>
            <th>PG</th>
            <th>Punti</th>
            <th>GF</th>
            <th>GS</th>
            <th>DR</th>
        </tr>
        <?php $pos = 1; foreach ($squadre as $s): ?>
            <tr>
                <td><?= $pos++ ?></td>
                <td><?= htmlspecialchars($s['nome']) ?></td>
                <td><?= $s['giocate'] ?></td>
                <td><?= $s['punti'] ?></td>
                <td><?= $s['gol_fatti'] ?></td>
                <td><?= $s['gol_subiti'] ?></td>
                <td><?= $s['diff'] ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div class="back">
        <a href="index.php" class="btn">🏠 Torna alla Home</a>
    </div>
</div>

</body>
</html>
